
using System;
using System.Windows.Forms;

namespace TogetherCultureApp
{
    public partial class EventPage : Form
    {
        public EventPage()
        {
            InitializeComponent();
        }

        private void btnSaveEvent_Click(object sender, EventArgs e)
        {
            string eventTitle = txtEventTitle.Text;
            string eventDescription = txtDescription.Text;
            DateTime eventDate = dtpEventDate.Value;

            MessageBox.Show($"Event Saved:\nTitle: {eventTitle}\nDescription: {eventDescription}\nDate: {eventDate.ToShortDateString()}");
        }
    }
}
