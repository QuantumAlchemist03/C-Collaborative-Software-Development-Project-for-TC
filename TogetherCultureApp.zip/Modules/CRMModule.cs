
using System;

namespace TogetherCultureApp.Modules
{
    public class CRMModule
    {
        public string MemberName { get; set; }
        public string MembershipType { get; set; }
        public string Interests { get; set; }

        public CRMModule(string memberName, string membershipType, string interests)
        {
            MemberName = memberName;
            MembershipType = membershipType;
            Interests = interests;
        }

        public string GetMemberDetails()
        {
            return $"Name: {MemberName}, Membership: {MembershipType}, Interests: {Interests}";
        }
    }
}
