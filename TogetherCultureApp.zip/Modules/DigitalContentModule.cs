
using System;

namespace TogetherCultureApp.Modules
{
    public class DigitalContentModule
    {
        public string ContentTitle { get; set; }
        public string ContentURL { get; set; }

        public DigitalContentModule(string title, string url)
        {
            ContentTitle = title;
            ContentURL = url;
        }

        public string GetContentDetails()
        {
            return $"Title: {ContentTitle}, URL: {ContentURL}";
        }
    }
}
